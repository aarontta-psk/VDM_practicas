package com.example.app_android;

public class Resources {
    // images
    public static String IMAGE_BACK_BUTTON = null;
    public static String IMAGE_TWITTER_BUTTON = null;
    public static String IMAGE_COIN = null;
    public static String IMAGE_LOCK = null;
    public static String IMAGE_HEART = null;
    public static String IMAGE_NO_HEART = null;
    public static String IMAGE_RECOVER_HEART = null;

    // fonts
    public static String FONT_EXO_REGULAR_BIG = null;
    public static String FONT_EXO_REGULAR_MEDIUM = null;
    public static String FONT_KOMIKAX = null;
    public static String FONT_SIMPLY_SQUARE_BIG = null;
    public static String FONT_SIMPLY_SQUARE_MEDIUM = null;

    // sounds
    public static String SOUND_BUTTON = null;
    public static String SOUND_CLICK = null;

    // music
    public static String MUSIC = null;
}
