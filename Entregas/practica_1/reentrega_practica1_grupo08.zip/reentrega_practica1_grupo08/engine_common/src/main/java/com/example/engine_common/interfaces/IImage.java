package com.example.engine_common.interfaces;

public interface IImage {
    public int getWidth();
    public int getHeight();
}
