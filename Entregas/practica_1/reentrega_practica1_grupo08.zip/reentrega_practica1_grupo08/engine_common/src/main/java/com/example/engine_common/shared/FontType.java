package com.example.engine_common.shared;

public enum FontType {
    DEFAULT,
    BOLD,
    ITALIC
}
