package com.example.engine_common.interfaces;

public interface ISound {
    public float getVolume();
    public void setVolume(float v);
}
