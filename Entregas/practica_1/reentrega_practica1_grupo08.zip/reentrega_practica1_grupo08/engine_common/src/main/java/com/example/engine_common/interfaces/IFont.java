package com.example.engine_common.interfaces;

public interface IFont {
    public int getSize();

    public boolean isBold();
    public boolean isItalic();
}