package com.example.engine_common.shared;

public enum InputType {
    TOUCH_DOWN,
    TOUCH_UP,
    TOUCH_MOVE
}